# orita-sdk (Python)

[![PyPI version](https://img.shields.io/pypi/v/orita-sdk.svg)](https://pypi.org/project/orita-sdk/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Provider resolution and scheduling infrastructure — official Python SDK**

[Orita](https://orita.online) finds the right provider across your network — applying license, insurance, modality, and availability constraints — then confirms the booking safely.

→ **API v2 docs:** [orita.online/developers](https://orita.online/developers)  
→ **API reference:** [orita.online/developers/reference](https://orita.online/developers/reference)  
→ **Node.js SDK:** [npmjs.com/package/orita-sdk](https://npmjs.com/package/orita-sdk)

---

## Installation

```bash
pip install orita-sdk
```

---

## Quick start

```python
from orita import OritaClient

orita = OritaClient(api_key="orita_...")

# 1. Resolve — find eligible providers with verified availability
resolution = orita.resolutions.create(
    service_id="svc_therapy_initial",
    date_range={
        "from": "2026-08-05",
        "to":   "2026-08-12",
        "timezone": "America/New_York"
    },
    constraints={
        "languageCodes":      {"anyOf": ["es"]},
        "modalityCodes":      {"anyOf": ["virtual"]},
        "licenseRegionCodes": {"anyOf": ["US-NJ"]},
        "insurancePlanCodes": {"anyOf": ["aetna"]},
        "acceptsNewClients":  True
    },
    preferences={
        "dayParts": ["afternoon"],
        "earliestAvailable": True
    }
)

# 2. Hold the chosen option
hold = orita.resolutions.hold_option(
    resolution["resolutionId"],
    resolution["options"][0]["optionId"]
)

# 3. Confirm exactly once
booking = orita.resolutions.confirm(
    resolution["resolutionId"],
    option_id=resolution["options"][0]["optionId"],
    hold_id=hold["holdId"],
    customer={"name": "James Park", "email": "james@example.com"},
    idempotency_key="confirm-customer-991"
)

print(booking["status"])  # "confirmed"
```

---

## Why resolution instead of direct booking

Use `resolutions.create` when you don't know which provider to use. Orita evaluates your entire provider network, applies eligibility rules, verifies availability, and returns ranked options with explanations.

---

## Provider imports

```python
job = orita.provider_imports.create(
    mode="upsert",
    dry_run=True,
    providers=[{
        "externalId":         "provider-2841",
        "displayName":        "Dr. Ana García",
        "professionCode":     "clinical_psychologist",
        "languageCodes":      ["es", "en"],
        "licenseRegionCodes": ["US-NJ"],
        "insurancePlanCodes": ["aetna"],
        "acceptsNewClients":  True
    }]
)
```

---

## Inspect every decision

```python
candidates = orita.resolutions.list_candidates(
    resolution_id, status="excluded"
)
# candidates[0]["exclusions"] = [{"code": "INSURANCE_NOT_ACCEPTED", ...}]
```

---

## API

```python
orita.resolutions.create(...)
orita.resolutions.get(resolution_id)
orita.resolutions.list_candidates(resolution_id, status=None)
orita.resolutions.hold_option(resolution_id, option_id)
orita.resolutions.release_hold(resolution_id, option_id)
orita.resolutions.confirm(resolution_id, ...)
orita.provider_imports.create(...)
orita.provider_imports.get(import_id)
orita.providers.list(...)
orita.providers.create(...)
orita.bookings.get(booking_id)
orita.bookings.reschedule(booking_id, ...)
orita.bookings.cancel(booking_id)
orita.ranking_policies.simulate(policy_id, ...)
```

---

## Documentation

- [API v2 overview](https://orita.online/developers)
- [Eligibility rules](https://orita.online/developers/eligibility.md)
- [Provider imports](https://orita.online/developers/provider-imports.md)
- [Webhooks](https://orita.online/developers/webhooks)
- [Migration v1 → v2](https://orita.online/developers/migration-v1-v2.md)
- [Full API reference](https://orita.online/developers/reference)
- [OpenAPI](https://orita.online/openapi.json)
