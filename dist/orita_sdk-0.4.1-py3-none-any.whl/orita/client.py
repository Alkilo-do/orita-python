import requests
from typing import Optional
from .exceptions import OritaError, OritaAuthError, OritaNotFoundError, OritaSlotUnavailableError

class OritaClient:
    BASE_URL = "https://orita.online/api/v1"

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        if not api_key.startswith("orita_"):
            raise OritaAuthError("API key must start with 'orita_'")
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def _request(self, method: str, path: str, headers: Optional[dict] = None, **kwargs):
        url = f"{self.base_url}{path}"
        response = self.session.request(method, url, headers=headers, **kwargs)
        if response.status_code == 401:
            raise OritaAuthError("Invalid API key")
        if response.status_code == 404:
            raise OritaNotFoundError(response.json().get("error", "Not found"))
        if response.status_code == 409:
            raise OritaSlotUnavailableError(response.json().get("error", "Slot unavailable"))
        if not response.ok:
            raise OritaError(response.json().get("error", "API error"))
        return response.json()

    def event_types(self, provider_id: Optional[str] = None) -> list:
        """List all active event types for this account (or a platform provider)."""
        params = {}
        if provider_id:
            params["providerId"] = provider_id
        return self._request("GET", "/event-types", params=params if params else None)["data"]

    def slots(self, event_type_id: str, date: str, provider_id: Optional[str] = None) -> list:
        """Get available time slots for an event type on a given date (YYYY-MM-DD)."""
        params = {
            "eventTypeId": event_type_id,
            "date": date,
        }
        if provider_id:
            params["providerId"] = provider_id
        data = self._request("GET", "/slots", params=params)
        return data["slots"]

    def book(
        self,
        event_type_id: Optional[str] = None,
        date: Optional[str] = None,
        time: Optional[str] = None,
        client_name: Optional[str] = None,
        client_lastname: Optional[str] = None,
        client_email: Optional[str] = None,
        provider_id: Optional[str] = None,
        slot_id: Optional[str] = None,
        customer: Optional[dict] = None,
        notes: Optional[str] = None,
    ) -> dict:
        """
        Book an appointment. Returns the booking object.

        You can either supply explicit date/time/client fields, or pass a
        ``slot_id`` (from ``slots()`` or ``solve_scheduling()``) together with
        a ``customer`` dict (keys: name, lastname, email, and optionally timezone).
        """
        payload = {}
        if event_type_id:
            payload["eventTypeId"] = event_type_id
        if date:
            payload["date"] = date
        if time:
            payload["time"] = time
        if client_name:
            payload["clientName"] = client_name
        if client_lastname:
            payload["clientLastname"] = client_lastname
        if client_email:
            payload["clientEmail"] = client_email
        if provider_id:
            payload["providerId"] = provider_id
        if slot_id:
            payload["slotId"] = slot_id
        if customer:
            payload["customer"] = customer
        if notes:
            payload["notes"] = notes
        return self._request("POST", "/bookings", json=payload)["data"]

    def bookings(self, page: int = 1, limit: int = 20, status: Optional[str] = None, provider_id: Optional[str] = None) -> list:
        """List bookings with optional status filter."""
        params = {"page": page, "limit": limit}
        if status:
            params["status"] = status
        if provider_id:
            params["providerId"] = provider_id
        return self._request("GET", "/bookings", params=params)["data"]

    def get_booking(self, booking_id: str) -> dict:
        """Get a booking by ID."""
        return self._request("GET", f"/bookings/{booking_id}")["data"]

    def cancel(self, booking_id: str) -> dict:
        """Cancel a booking by ID."""
        return self._request("POST", f"/bookings/{booking_id}/cancel")["data"]

    def reschedule(self, booking_id: str, date: str, time: str) -> dict:
        """
        Reschedule an existing booking to a new date and time.

        Args:
            booking_id: The booking ID to reschedule.
            date: New date in YYYY-MM-DD format.
            time: New time in HH:MM 24h format (e.g. "10:00").

        Returns:
            dict with updated booking data.

        Example:
            result = orita.reschedule("bk_18382", date="2026-08-05", time="10:00")
        """
        return self._request(
            "POST",
            f"/bookings/{booking_id}/reschedule",
            json={"date": date, "time": time}
        )

    def complete(self, booking_id: str) -> dict:
        """
        Mark a booking as completed.

        Args:
            booking_id: The booking ID to complete.

        Returns:
            dict with updated booking data.
        """
        return self._request("POST", f"/bookings/{booking_id}/complete")

    def professionals(
        self,
        language: Optional[str] = None,
        modality: Optional[str] = None,
        specialty: Optional[str] = None,
        profession: Optional[str] = None,
        location: Optional[str] = None,
    ) -> list:
        """List professionals on the platform, with optional filters."""
        params = {}
        if language:
            params["language"] = language
        if modality:
            params["modality"] = modality
        if specialty:
            params["specialty"] = specialty
        if profession:
            params["profession"] = profession
        if location:
            params["location"] = location
        return self._request("GET", "/professionals", params=params if params else None)["data"]

    def create_event_type(
        self,
        title: str,
        duration: int,
        location: str = "Online",
        description: str = "",
        availability_id: Optional[str] = None,
        provider_id: Optional[str] = None,
        buffer_time: int = 15,
        scheduling_notice_days: str = "0",
        scheduling_notice_hours: str = "0",
    ) -> dict:
        """Create a new event type. Returns the created event type."""
        payload = {
            "title": title,
            "duration": duration,
            "location": location,
            "description": description,
            "bufferTime": buffer_time,
            "schedulingNoticeDays": scheduling_notice_days,
            "schedulingNoticeHours": scheduling_notice_hours,
        }
        if availability_id:
            payload["availabilityId"] = availability_id
        if provider_id:
            payload["providerId"] = provider_id
        return self._request("POST", "/event-types", json=payload)["data"]

    def profile(self) -> dict:
        """Get your agent capability manifest (Capability Manifest)."""
        return self._request("GET", "/profile")["data"]

    def update_profile(self, **fields) -> dict:
        """Update your agent profile fields."""
        return self._request("PUT", "/profile", json=fields)["data"]

    def get_profile(self, username: str) -> dict:
        """Get the public Capability Manifest for any professional by username (no auth needed)."""
        import requests as req
        response = req.get(f"{self.base_url}/profile", params={"username": username})
        if response.status_code == 404:
            raise OritaNotFoundError(f"Professional '{username}' not found")
        return response.json()["data"]

    def solve_scheduling(
        self,
        event_type_id: str,
        date_range_from: str,
        date_range_to: str,
        provider_id: Optional[str] = None,
        preference: Optional[str] = None,
    ) -> dict:
        """
        Find the best available slot across a date range (AI-agent optimized).

        :param event_type_id: The event type ID.
        :param date_range_from: Start date in YYYY-MM-DD format.
        :param date_range_to: End date in YYYY-MM-DD format.
        :param provider_id: Optional platform provider ID.
        :param preference: Optional time-of-day preference: 'morning', 'afternoon', or 'evening'.
        :returns: Dict with keys: recommended, alternatives, totalAvailableSlots, reason.
        """
        payload = {
            "eventTypeId": event_type_id,
            "dateRange": {"from": date_range_from, "to": date_range_to},
        }
        if provider_id:
            payload["providerId"] = provider_id
        if preference:
            payload["preference"] = preference
        return self._request("POST", "/solve-scheduling", json=payload)

    def resolve_scheduling(
        self,
        date_range_from: str,
        date_range_to: str,
        constraints: Optional[dict] = None,
        service: Optional[str] = None,
        preference: Optional[str] = None,
        organization_id: Optional[str] = None,
    ) -> list:
        """
        Resolve the best available providers and slots for a scheduling request.
        Use when you don't know a specific provider or event type yet.

        :param date_range_from: Start date in YYYY-MM-DD format.
        :param date_range_to: End date in YYYY-MM-DD format.
        :param constraints: Optional dict with keys: language, modality, specialty, profession.
        :param service: Optional event type title or slug to narrow results.
        :param preference: Optional time-of-day preference: 'morning', 'afternoon', or 'evening'.
        :param organization_id: Optional organization ID (future-proofing; ignored server-side).
        :returns: List of option dicts with keys: providerId, providerName, eventTypeId,
                  slotId, date, time, label, modality, reason.
        """
        payload = {
            "dateRange": {"from": date_range_from, "to": date_range_to},
        }
        if constraints:
            payload["constraints"] = constraints
        if service:
            payload["service"] = service
        if preference:
            payload["preference"] = preference
        if organization_id:
            payload["organizationId"] = organization_id
        return self._request("POST", "/resolve-scheduling", json=payload)

    def get_resolution(self, resolution_id: str) -> dict:
        """
        Retrieve a stored resolution by ID, including all ranked options and scores.

        Args:
            resolution_id: The resolution ID returned by resolve_scheduling.

        Returns:
            dict with resolutionId, status, summary, options, exclusions, warnings.

        Example:
            resolution = orita.get_resolution("a1b2c3d4-...")
            print(resolution['options'][0]['reason'])
        """
        return self._request("GET", f"/resolutions/{resolution_id}")

    def hold_option(self, resolution_id: str, option_id: str, ttl_seconds: int = 120) -> dict:
        """
        Temporarily hold a resolution option (prevents others from booking it).

        Args:
            resolution_id: Resolution ID from resolve_scheduling.
            option_id: Option ID to hold (from resolution options list).
            ttl_seconds: Hold duration in seconds (default 120, max 600).

        Returns:
            dict with holdId, status, expiresAt.

        Example:
            hold = orita.hold_option(resolution_id, option_id, ttl_seconds=180)
            print(hold['expiresAt'])
        """
        return self._request(
            "POST",
            f"/resolutions/{resolution_id}/options/{option_id}/hold",
            json={"ttlSeconds": ttl_seconds}
        )

    def release_option(self, resolution_id: str, option_id: str) -> dict:
        """
        Release a previously held resolution option.

        Args:
            resolution_id: Resolution ID.
            option_id: Option ID of the hold to release.

        Returns:
            dict with holdId, status='released'.
        """
        return self._request(
            "DELETE",
            f"/resolutions/{resolution_id}/options/{option_id}/hold"
        )

    def confirm_resolution(
        self,
        resolution_id: str,
        option_id: str,
        customer_name: str,
        customer_email: str,
        customer_lastname: str = "-",
        metadata: Optional[dict] = None,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        """
        Confirm a resolution option and atomically create a booking.
        This is the final step after resolve_scheduling.

        Args:
            resolution_id: Resolution ID from resolve_scheduling.
            option_id: Option ID to confirm (from resolution options).
            customer_name: Customer full name.
            customer_email: Customer email address.
            customer_lastname: Customer last name (default '-').
            metadata: Optional metadata dict (e.g. {'source': 'ai_assistant'}).
            idempotency_key: Optional idempotency key for safe retries.

        Returns:
            dict with data.id (booking ID) and data.status.

        Example:
            booking = orita.confirm_resolution(
                resolution_id=res['resolutionId'],
                option_id=res['options'][0]['optionId'],
                customer_name='James Park',
                customer_email='james@email.com'
            )
            print(booking['data']['id'])
        """
        extra_headers = {}
        if idempotency_key:
            extra_headers['Idempotency-Key'] = idempotency_key

        body = {
            "optionId": option_id,
            "customer": {
                "name": customer_name,
                "email": customer_email,
                "lastname": customer_lastname,
            },
        }
        if metadata:
            body["metadata"] = metadata

        return self._request(
            "POST",
            f"/resolutions/{resolution_id}/confirm",
            json=body,
            headers=extra_headers if extra_headers else None,
        )
